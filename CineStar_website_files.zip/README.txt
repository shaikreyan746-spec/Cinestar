CineStar — free movie discovery website

Files:
- index.html: the complete responsive website. Open it in a browser to preview.

Features:
- Search by movie title and genre
- Genre filters
- Movie detail popup and ratings (sample demo data)
- Trailer finder that searches YouTube for official/authorized trailers
- Watchlist saved locally in the same browser/device
- Mobile-friendly layout
- Ready to publish as a static site

Publish free with GitHub Pages:
1. Create/sign in to a GitHub account.
2. Create a new public repository, e.g. cinestar.
3. Upload index.html to the repository root.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for the published URL shown on the Pages settings screen.

Notes:
- This demo does not host full copyrighted movies. The trailer buttons search YouTube for official/authorized trailers.
- Movie ratings/descriptions are sample content for the demo, not live data.
- Watchlist is saved only in this browser using localStorage.
