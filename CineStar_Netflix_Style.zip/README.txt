CineStar Netflix-style website
Upload index.html to the root of your GitHub repository and commit changes to the main branch.
Then check Settings > Pages: Deploy from a branch, main, /(root).
Wait for GitHub Pages to deploy and refresh your live website.
The website embeds YouTube trailers; some videos may block embedding, so use Open on YouTube. Movie ratings/descriptions are sample content. It does not host full movies.
